#Usage

Provided within this folder is an example of how to easily create a turbomole job and all the requisite files.

The only thing you need to do is specify the .xyz file you would like to use for the calculation and the yaml file with the parameters of your choice. Documentation for the turbomoleio parameters can be found on their [github repository](https://matgenix.github.io/turbomoleio/definerunner.html). 

Keep in mind that you do not need to generate your own coord file. That is handled by the script for convenience. 
